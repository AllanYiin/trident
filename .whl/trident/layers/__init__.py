"""trident layers"""
