from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from functools import reduce
from functools import wraps
import math
import collections
import itertools
import tensorflow as tf
from torch._six import container_abcs
import tensorflow.keras.backend as K
from tensorflow_core.python.keras.utils import conv_utils
from tensorflow.python.framework import tensor_shape
from tensorflow.python.keras.engine.input_spec import InputSpec
from tensorflow.python.ops import nn_ops
from tensorflow.python.client import device_lib
from .tensorflow_activations import get_activation
from .tensorflow_pooling import get_pooling,GlobalAvgPool2d
from .tensorflow_normalizations import get_normalization
from .tensorflow_layers import *

from itertools import repeat
import inspect

from ..backend.common import *
from ..backend.tensorflow_backend import *




_tf_data_format= 'channels_last'

__all__ = ['Conv2d_Block', 'TransConv2d_Block']


_session = get_session()


def get_layer_repr(layer):
    # We treat the extra repr like the sub-module, one item per line
    extra_lines = []
    if hasattr( layer, 'extra_repr' ) and callable( layer.extra_repr ):
        extra_repr = layer.extra_repr()
        # empty string will be split into list ['']
        if extra_repr:
            extra_lines = extra_repr.split('\n')
    child_lines = []
    if isinstance(layer,(tf.keras.Model,tf.keras.Sequential)) and layer.layers is not None:
        for module in layer.layers:
            mod_str = repr(module)
            mod_str = addindent(mod_str, 2)
            child_lines.append('(' + module.name + '): ' + mod_str)
    lines = extra_lines + child_lines

    main_str = layer.__class__.__name__ + '('
    if lines:
        # simple one-liner info, which most builtin Modules will use
        if len(extra_lines) == 1 and not child_lines:
            main_str += extra_lines[0]
        else:
            main_str += '\n  ' + '\n  '.join(lines) + '\n'

    main_str += ')'
    return main_str


class Conv1d_Block(Sequential):
    def __init__(self, kernel_size=(3), num_filters=32, strides=1, auto_pad=True,activation='leaky_relu',normalization=None,  use_bias=False,dilation=1, groups=1,add_noise=False,noise_intensity=0.001,dropout_rate=0, **kwargs ):
        super(Conv1d_Block, self).__init__()
        if add_noise:
            noise = tf.keras.layers.GaussianNoise(noise_intensity)
            self.add(noise)
        self._conv = Conv1d(kernel_size=kernel_size, num_filters=num_filters, strides=strides, auto_pad=auto_pad,
                      activation=None, use_bias=use_bias, dilation=dilation, groups=groups)
        self.add(self._conv)

        self.norm = get_normalization(normalization)
        if self.norm is not None:
            self.add(self.norm)

        self.activation = get_activation(snake2camel(activation))
        if self.activation is not None:
            self.add(self.activation)
        if dropout_rate > 0:
            self.drop = Dropout(dropout_rate)
            self.add(self.drop)
    @property
    def conv(self):
        return self._conv
    @conv.setter
    def conv(self,value):
        self._conv=value




class Conv2d_Block(Sequential):
    def __init__(self, kernel_size=(3,3), num_filters=32, strides=1, auto_pad=True,activation='leaky_relu',normalization=None,  use_bias=False,dilation=1, groups=1,add_noise=False,noise_intensity=0.001,dropout_rate=0, **kwargs ):
        super(Conv2d_Block, self).__init__()
        if add_noise:
            noise = tf.keras.layers.GaussianNoise(noise_intensity)
            self.add(noise)
        self._conv = Conv2d(kernel_size=kernel_size, num_filters=num_filters, strides=strides, auto_pad=auto_pad,
                      activation=None, use_bias=use_bias, dilation=dilation, groups=groups)
        self.add(self._conv)

        self.norm = get_normalization(normalization)
        if self.norm is not None:
            self.add(self.norm)

        self.activation = get_activation(snake2camel(activation))
        if self.activation is not None:
            self.add(self.activation)
        if dropout_rate > 0:
            self.drop = Dropout(dropout_rate)
            self.add(self.drop)
    @property
    def conv(self):
        return self._conv
    @conv.setter
    def conv(self,value):
        self._conv=value



class Conv3d_Block(Sequential):
    def __init__(self, kernel_size=(3,3,3), num_filters=32, strides=1, auto_pad=True,activation='leaky_relu',normalization=None,  use_bias=False,dilation=1, groups=1,add_noise=False,noise_intensity=0.001,dropout_rate=0, **kwargs ):
        super(Conv3d_Block, self).__init__()
        if add_noise:
            noise = tf.keras.layers.GaussianNoise(noise_intensity)
            self.add(noise)
        self._conv = Conv3d(kernel_size=kernel_size, num_filters=num_filters, strides=strides, auto_pad=auto_pad,
                      activation=None, use_bias=use_bias, dilation=dilation, groups=groups)
        self.add(self._conv)

        self.norm = get_normalization(normalization)
        if self.norm is not None:
            self.add(self.norm)

        self.activation = get_activation(snake2camel(activation))
        if self.activation is not None:
            self.add(self.activation)
        if dropout_rate > 0:
            self.drop = Dropout(dropout_rate)
            self.add(self.drop)
    @property
    def conv(self):
        return self._conv
    @conv.setter
    def conv(self,value):
        self._conv=value




#
# class TransConv1d_Block(Sequential):
#     def __init__(self, kernel_size=(3), num_filters=32, strides=1, auto_pad=True,activation='leaky_relu',normalization=None,  use_bias=False,dilation=1, groups=1,add_noise=False,noise_intensity=0.001,dropout_rate=0, **kwargs ):
#         super(TransConv1d_Block, self).__init__()
#         if add_noise:
#             noise = tf.keras.layers.GaussianNoise(noise_intensity)
#             self.add(noise)
#         self._conv = TransConv1d(kernel_size=kernel_size, num_filters=num_filters, strides=strides, auto_pad=auto_pad,
#                       activation=None, use_bias=use_bias, dilation=dilation, groups=groups)
#         self.add(self._conv)
#
#         self.norm = get_normalization(normalization)
#         if self.norm is not None:
#             self.add(self.norm)
#
#         self.activation = get_activation(activation)
#         if self.activation is not None:
#             self.add(activation)
#         if dropout_rate > 0:
#             self.drop = Dropout(dropout_rate)
#             self.add(self.drop)
#     @property
#     def conv(self):
#         return self._conv
#     @conv.setter
#     def conv(self,value):
#         self._conv=value
#
#
#     def __repr__(self):
#         return get_layer_repr(self)


class TransConv2d_Block(Sequential):
    def __init__(self, kernel_size=(3,3), num_filters=32, strides=1, auto_pad=True,activation='leaky_relu',normalization=None,  use_bias=False,dilation=1, groups=1,add_noise=False,noise_intensity=0.001,dropout_rate=0, **kwargs ):
        super(TransConv2d_Block, self).__init__()
        if add_noise:
            noise = tf.keras.layers.GaussianNoise(noise_intensity)
            self.add(noise)
        self._conv = TransConv2d(kernel_size=kernel_size, num_filters=num_filters, strides=strides, auto_pad=auto_pad,
                      activation=None, use_bias=use_bias, dilation=dilation, groups=groups)
        self.add(self._conv)

        self.norm = get_normalization(normalization)
        if self.norm is not None:
            self.add(self.norm)

        self.activation = get_activation(snake2camel(activation))
        if self.activation is not None:
            self.add(self.activation)
        if dropout_rate > 0:
            self.drop = Dropout(dropout_rate)
            self.add(self.drop)
    @property
    def conv(self):
        return self._conv
    @conv.setter
    def conv(self,value):
        self._conv=value


class TransConv3d_Block(Sequential):
    def __init__(self, kernel_size=(3,3,3), num_filters=32, strides=1, auto_pad=True,activation='leaky_relu',normalization=None,  use_bias=False,dilation=1, groups=1,add_noise=False,noise_intensity=0.001,dropout_rate=0, **kwargs ):
        super(TransConv3d_Block, self).__init__()
        if add_noise:
            noise = tf.keras.layers.GaussianNoise(noise_intensity)
            self.add(noise)
        self._conv = TransConv3d(kernel_size=kernel_size, num_filters=num_filters, strides=strides, auto_pad=auto_pad,
                      activation=None, use_bias=use_bias, dilation=dilation, groups=groups)
        self.add(self._conv)

        self.norm = get_normalization(normalization)
        if self.norm is not None:
            self.add(self.norm)

        self.activation = get_activation(snake2camel(activation))
        if self.activation is not None:
            self.add(self.activation)
        if dropout_rate > 0:
            self.drop = Dropout(dropout_rate)
            self.add(self.drop)
    @property
    def conv(self):
        return self._conv
    @conv.setter
    def conv(self,value):
        self._conv=value



class Classifer1d(Sequential):
    def __init__(self, num_classes=10, is_multilable=False, classifier_type=ClassfierType.dense, **kwargs ):
        super(Classifer1d, self).__init__()
        self.classifier_type = classifier_type
        self.num_classes = num_classes
        self.is_multilable = is_multilable
        if classifier_type==ClassfierType.dense:
            self.add(Flatten)
            self.add(Dense(num_classes,use_bias=False,activation='sigmoid'))
            if not is_multilable:
                self.add(SoftMax)
        elif classifier_type==ClassfierType.global_avgpool:
            self.add(Conv2d((1,1),num_classes,strides=1,auto_pad=True,activation=None))
            self.add(GlobalAvgPool2d)
            if not is_multilable:
                self.add(SoftMax)




    def __repr__(self):
        return get_layer_repr(self)



