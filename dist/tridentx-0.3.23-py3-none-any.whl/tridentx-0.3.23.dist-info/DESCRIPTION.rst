### Trident 

### Learning Trident 

You can learn more about using and contributing to CNTK with the following resources:

* [General documentation](https://docs.microsoft.com/en-us/cognitive-toolkit/)
* [CNTK Examples](./exsamples_cntk)
* [Pytorch Examples](./exsamples_tensorflow)
* [Tensorflow Examples](./exsamples_pytorch)
* [Pretrained models](./PretrainedModels)
* [License](./LICENSE.md)




