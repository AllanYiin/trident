from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from backend.common import  epsilon,floatx

import cntk as C
from cntk.internal import *
from cntk.ops.functions import Function, BlockFunction
from cntk.variables import Parameter, Record, Constant
import six
from cntk.internal import *
from backend.cntk_backend import *

@C.typemap
def identity(x,name=''):
    @C.BlockFunction('identity', name=name)
    def apply_x(x):
        x = sanitize_input(x)
        return x
    return apply_x(x)

@C.typemap
def sigmoid(x,name=''):
    @C.BlockFunction('sigmoid', name=name)
    def apply_x(x):
        x = sanitize_input(x)
        return C.sigmoid(x)
    return apply_x(x)

@C.typemap
def tanh(x,name=''):
    @C.BlockFunction('tanh', name=name)
    def apply_x(x):
        x = sanitize_input(x)
        return C.tanh(x)
    return apply_x(x)

@C.typemap
def relu(x,upper_limit=np.inf,name=''):
    if upper_limit<=0:
        raise ValueError('Upper limit should greater than 0!')
    if upper_limit is not None:
        return C.clip(C.relu(x),0.,float(upper_limit),name=name)
    return C.relu(x,name=name)


@C.typemap
def relu6(x,name='relu6'):
     return C.clip(C.relu(x) ,0 ,6)




@C.typemap
def leaky_relu(x,alpha=0.01,upper_limit=np.inf,name=''):
    if upper_limit<=0:
        raise ValueError('Upper limit should greater than 0!')
    x = sanitize_input(x)
    if upper_limit is not None:
        return C.clip(C.leaky_relu(x,alpha),-1*upper_limit,upper_limit,name=name)
    return C.leaky_relu(x,alpha,name=name)


@C.typemap
def elu(x,alpha=0.01,upper_limit=np.inf,name=''):
    return C.elu(x,alpha)

lrelu=leaky_relu

@C.typemap
def smooth_relu(x,name=''):
     return C.log(1 + C.exp(x))

@C.typemap
def prelu(x,name=''):
    @C.BlockFunction('prelu', name=name)
    def apply_x(x):
        x = sanitize_input(x)
        alpha=C.Parameter(x.shape, init=C.he_normal())
        return C.param_relu(alpha,x)
    return apply_x(x)

@C.typemap
def swish(x,name=''):
    @C.BlockFunction('swish', name=name)
    def apply_x(x):
        x = sanitize_input(x)
        r = C.element_times(x, C.sigmoid(x))
        return r
    return apply_x(x)


@C.typemap
def selu(x,name=''):
    @C.BlockFunction('selu', name=name)
    def apply_x(x):
        x = sanitize_input(x)
        return C.selu(x)
    return apply_x(x)

def lecun_tanh(x,name=''):
    x = sanitize_input(x)
    return 1.7159 * C.tanh(2/3 * x)


@C.typemap
def softsign(x,name=''):
    @C.BlockFunction('softsign', name=name)
    def apply_x(x):
        x = sanitize_input(x)
        return C.log(1 + C.exp(x))
    return apply_x(x)

@C.typemap
def softplus(x,name=''):
    @C.BlockFunction('softplus', name=name)
    def apply_x(x):
        return C.log(C.exp(x) + 1)
    return apply_x(x)


@C.typemap
def hard_sigmoid(x,name=''):
    @C.BlockFunction('hard_sigmoid', name=name)
    def apply_x(x):
        x = sanitize_input(x)
        x = (0.2 * x) + 0.5
        x = C.clip(x, 0.0, 1.0)
        return x
    return apply_x(x)

@C.typemap
def hard_tanh(x,name=''):
    @C.BlockFunction('hard_tanh', name=name)
    def apply_x(x):
        x = sanitize_input(x)
        return C.clip(x,-1,1)
    return apply_x(x)


@C.typemap
def logit(x,name=''):
    @C.BlockFunction('logit', name=name)
    def apply_x(x):
        x = sanitize_input(x)
        return C.log(x / (1 - x))
    return apply_x(x)



@C.typemap
def loglog(x,name=''):
    @C.BlockFunction('loglog', name=name)
    def apply_x(x):
        x = sanitize_input(x)
        return 1-C.exp(-C.exp(x))
    return apply_x(x)


@C.typemap
def softmax(x,name=''):
    @C.BlockFunction('softmax', name=name)
    def apply_x(x):
        x = sanitize_input(x)
        return C.softmax(x)
    return apply_x(x)



def get_activation(identifier):
    if identifier is None:
        return identity()
    if isinstance(identifier, six.string_types):
        identifier = str(identifier)
        fn=relu
        mod=fn.__module__
        obj_dict = fn.__globals__
        for k, v in obj_dict.items():
            if k == identifier and mod=='trident.backend.cntk_activations':
                fn = v
                return fn
        raise ValueError('Not valid activation functions name : ' + str(identifier))



# def get(identifier):
#
#     """Get the `identifier` activation function.
#
#
#
#     # Arguments
#
#         identifier: None or str, name of the function.
#
#
#
#     # Returns
#
#         The activation function, `linear` if `identifier` is None.
#
#
#
#     # Raises
#
#         ValueError if unknown identifier
#
#     """
#     if identifier is None:
#         return C.ops.lea
#     if isinstance(identifier, six.string_types):
#         identifier = str(identifier)
#         return deserialize(identifier)
#     elif callable(identifier):
#         if isinstance(identifier, Layer):
#             warnings.warn(
#                 'Do not pass a layer instance (such as {identifier}) as the '
#                 'activation argument of another layer. Instead, advanced '
#                 'activation layers should be used just like any other '
#                 'layer in a model.'.format(
#                     identifier=identifier.__class__.__name__))
#         return identifier
#     else:
#         raise ValueError('Could not interpret '
#                          'activation function identifier:', identifier)